package com.example.modul4

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.google.android.material.button.MaterialButton
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val buttonBookNow: MaterialButton =
            findViewById(R.id.button_book_now)
        buttonBookNow.setOnClickListener {
            Toast.makeText(this, "Pemesanan paket wisata berhasil!", Toast.LENGTH_SHORT).show()
        }
        val buttonDetails: MaterialButton =
            findViewById(R.id.button_details)
        buttonDetails.setOnClickListener {
            Toast.makeText(this, "Menampilkan detail paket wisata...", Toast.LENGTH_SHORT).show()
        }
        }
}